"""pypi_test_app package."""

from .main import create_app

__version__ = "0.1.4"
__all__ = ["create_app", "__version__"]
