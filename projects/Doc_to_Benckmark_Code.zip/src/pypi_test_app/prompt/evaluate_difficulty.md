### Instruction ### 
-입력된 QA 데이터의 난이도를 평가하세요.

**평가 기준**
1. 필요한 배경 지식의 수준
2. 추론과 분석의 복잡성
3. 전문 용어와 개념의 어려움
4. Context에서 답을 찾는 난이도
5. 종합적 사고력 요구 수준

**평가 기준**:
1점: very easy 
2점: easy 
3점: medium 
4점: hard 
5점: very hard 

### Input ### 
Context: 문맥 정보
Question: Context 기반 생성 질문
Answer: Context 기반 생성 정답

### Output ### 
Context
Question
Answer
Difficulty: 난이도(1점-5점)
Difficulty_Reason: 난이도 평가 근거 